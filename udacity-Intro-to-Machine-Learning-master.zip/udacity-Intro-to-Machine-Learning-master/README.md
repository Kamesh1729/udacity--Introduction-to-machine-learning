**Intro to Machine Learning**

My solutions to the Udacity course "Intro to Machine Learning"

Cloned from:

https://github.com/udacity/ud120-projects

ud120-projects
==============

Starter project code for students taking Udacity ud120
